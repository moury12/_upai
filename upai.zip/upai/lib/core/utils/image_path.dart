class ImageConstant {
  // Image folder path
  static const String _imagePath = 'assets/images';

  //Images
  static String accountImg = '$_imagePath/account.svg';
  static String home = '$_imagePath/home.png';

}
