import 'package:flutter/material.dart';
import 'package:upai/core/utils/custom_text_style.dart';

class ChatItemWidget extends StatelessWidget {
  const ChatItemWidget({super.key});

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: Image.asset("assets/images/demoprofile.png"),
      title: Text("Jhenny Wilson",style: AppTextStyle.bodyMedium,),
      subtitle: Text("Can you please do the work for me?",overflow: TextOverflow.ellipsis,),
       trailing: Column(
         crossAxisAlignment: CrossAxisAlignment.center,
         children: [
           Text("10:39"),
         ],
       ) ,
    );
  }
}
